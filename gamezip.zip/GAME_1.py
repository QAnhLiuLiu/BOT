import pygame, sys, random
pygame.init()

#Hàm_________________________________________________________________________
def create_stone():
    random_stone_pos = random.choice(stone_height)
    new_stone = stone_surface.get_rect(center = (1000,  random_stone_pos))
    return new_stone

def move_stone(stones, score):
    for stone in stones:
        stone.centerx -= 5
        if stone.centerx == 130:
           score_sound.play()
           score += 1
    return stones, score

def draw_stone(stones):
    for stone in stones:
        screen.blit(stone_surface,stone) 



def check_collision(stones):
    for stone in stones:
        if plane_rect.colliderect(stone):
            plane_explode_sound.play()
            return "game_over"
    if plane_rect.top <= 0 or plane_rect.bottom >= 500:
        plane_explode_sound.play()
        return "game_over"
    return "game_playing"



def draw_plane_bg():
    screen.blit(plane_bg, (plane_bg_x_pos,340))
    #if floor_x_pos == -2924:
    screen.blit(plane_bg, (plane_bg_x_pos + 1272 ,340))



def draw_floor():
    screen.blit(floor, (floor_x_pos,320))
    #if floor_x_pos == -2924:
    screen.blit(floor, (floor_x_pos + 3924,320))



def update_score(score, high_score): 
    if score > high_score: 
        high_score = score
    return high_score

def score_display(game_state):
    if game_state == "game_playing":
        score_surface = game_font.render(str(int(score)), True, (16, 51, 125))
        score_rect = score_surface.get_rect(center = (40, 40)) #vị trí số điểm
        screen.blit(score_surface, score_rect)
    if game_state == "game_over":
        score_surface = game_font.render(f'SCORE: {int(score)}', True, (16, 51, 125))
        score_rect = score_surface.get_rect(center = (510, 240)) #vị trí số điểm
        screen.blit(score_surface, score_rect)

        high_score_surface = game_font.render(f'BEST SCORE: {int(high_score)}', True, (16, 51, 125))
        high_score_rect = high_score_surface.get_rect(center = (510, 300)) #vị trí số điểm
        screen.blit(high_score_surface, high_score_rect)

        game_over_surface = game_font_game_over.render(f'GAME OVER', True, (0, 0, 0))
        game_over_rect = game_over_surface.get_rect(center = (510, 150)) #vị trí số điểm
        screen.blit(game_over_surface, game_over_rect)

        game_over_continue = game_font_continue.render('CLICK TO CONTINUE', True, (0, 0 ,0))
        game_over_continue_rect = game_over_continue.get_rect(center = (510, 360)) #vị trí số điểm
        screen.blit(game_over_continue,  game_over_continue_rect)





#Biến____________________________________________________________________
game_font = pygame.font.Font("D:\\game\\04B_19.ttf", 60)
game_font_game_over = pygame.font.Font("D:\\game\\04B_19.ttf", 100)
game_font_continue = pygame.font.Font("D:\\game\\04B_19.ttf", 40)

screen = pygame.display.set_mode((1000,527))
clock = pygame.time.Clock()
bg = pygame.image.load("D:\\game\images\sky.png")
bg_start = pygame.image.load("D:\game\images\PLANEGAME.png")
plane_bg = pygame.image.load("D:\game\images\plane_bg.png")
plane_bg_x_pos = 1200 

floor_bg = pygame.image.load("D:\game\images\san_bg.png")
floor = pygame.image.load('D:\game\images\san-removebg-preview.png')
floor = pygame.transform.scale(floor, (3924,288))
floor_x_pos = 0

plane = pygame.image.load('D:\game\images\plane2.png')
plane = pygame.transform.scale(plane, (80, 40))
plane_rect = plane.get_rect(center = (250,250)) #HCN quanh máy bay
gravity = 0.25 #trọng lực
plane_move = 0 
flap_sound = pygame.mixer.Sound("D:\game\sound\sfx_wing.wav")
plane_explode_sound = pygame.mixer.Sound("D:\game\sound\Tieng-min-no-www_tiengdong_com.wav")

game_active = "game_start"

score = 0
high_score = 0
score_sound = pygame.mixer.Sound("D:\game\sound\sfx_point.wav")

stone_surface = pygame.image.load("D:\game\images\stone.png")
stone_surface = pygame.transform.scale(stone_surface, (40, 40))
stone_list = []
#tạo thời gian xuất hiện đá
spawnstone = pygame.USEREVENT
pygame.time.set_timer(spawnstone, 1000) #sau 1,2s sẽ tạo đá
stone_height = [100,150, 200, 250, 300, 350]




#Vòng lặp game______________________________________________________________________
while True:
    for event in pygame.event.get():
        if event.type == pygame.MOUSEBUTTONDOWN:
            if pygame.mouse.get_pressed()[0] and game_active == "game_start" : 
                game_active = "game_playing"
                plane_rect.center = (250, 250)
                plane_move = 0
            if pygame.mouse.get_pressed()[0] and game_active == "game_over" : 
                game_active = "game_playing"
                plane_rect.center = (250, 250)
                plane_move = 0
                stone_list.clear()
                score = 0

        if event.type == pygame.KEYDOWN:
            if event.key == pygame.K_SPACE and game_active == "game_playing" :
                plane_move = 0
                plane_move -= 7
                flap_sound.play()

        if event.type == pygame.QUIT:  
            pygame.quit()
            sys.exit()

        if event.type == spawnstone and game_active == "game_playing":
           stone_list.append(create_stone())

    if game_active == "game_start":
        screen.blit(bg_start, (0,0))
        screen.blit(floor_bg, (-10, 480))
        plane_bg_x_pos -= 4
        draw_plane_bg()
        if plane_bg_x_pos <= -272:
            plane_bg_x_pos = 1000



    elif game_active == "game_playing":
        screen.blit(bg, (0,0))
    #Cục đá
        list = move_stone(stone_list, score) 
        stone_list = list[0]
        score = list[1]
        draw_stone(stone_list) 
        
    #nền đất
        floor_x_pos -= 6
        draw_floor()
        if floor_x_pos <= -3924:
            floor_x_pos = 0

    #máy bay
        screen.blit(plane, plane_rect)
        plane_move += gravity
        plane_rect.centery += plane_move
        game_active = check_collision(stone_list) 
    
    #điểm
        score_display("game_playing")

    else:
        high_score = update_score(score, high_score)
        score_display("game_over") 
        #screen.blit(game_over_surface, game_over_rect)
    

    pygame.display.update()
    clock.tick(120)
        

        

        
         
                 